<nav class="navbar">
    <a href="index.php"> <i class="fas fa-home"></i> <span>home</span> </a>
    <a href="about.php"> <i class="fas fa-user"></i> <span>about</span> </a>
    <a href="portfolio.php"> <i class="fas fa-briefcase"></i> <span>portfolio</span> </a>
    <a href="contact.php"> <i class="fas fa-address-book"></i> <span>contact</span> </a>
</nav>